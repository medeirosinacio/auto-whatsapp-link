## Auto WhatsApp Link

### *pt-BR*
Uma extensão para enviar mensagens via WhatsApp para numeros de telefones selecionado

### *en-US*
An extension to send messages via WhatsApp to selected phone numbers

![screenshot](./screenshot.png)